from inc import inc
def test_inc():
     assert inc(3) == 4
