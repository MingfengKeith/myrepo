def inc(x):
    if x < 0:
        return 0
    return x + 1
def dec(x):
     return x - 1
