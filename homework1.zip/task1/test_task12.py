from task12 import fib


def test_fib():
    assert fib(2) == 1
    assert fib(5) == 5
    assert fib(12) == 144
